import App from './modules/app.js'; 
const app = new App();